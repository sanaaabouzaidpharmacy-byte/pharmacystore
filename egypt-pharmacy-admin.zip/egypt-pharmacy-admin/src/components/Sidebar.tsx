import React from 'react';

interface SidebarProps {
  isOpen: boolean;
  currentPage: string;
  onNavigate: (page: any) => void;
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, currentPage, onNavigate, onLogout }) => {
  const menuItems = [
    { id: 'dashboard', label: 'لوحة التحكم', icon: '📊', color: 'text-blue-600' },
    { id: 'products', label: 'المنتجات', icon: '💊', color: 'text-green-600' },
    { id: 'orders', label: 'الطلبات', icon: '📦', color: 'text-orange-600' },
    { id: 'users', label: 'المستخدمين', icon: '👥', color: 'text-purple-600' },
    { id: 'categories', label: 'الأقسام', icon: '📂', color: 'text-pink-600' },
  ];

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => onNavigate(currentPage)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed right-0 top-0 h-full bg-slate-800 text-white z-50 transition-all duration-300 ${
          isOpen ? 'w-64' : 'w-0 lg:w-20'
        } overflow-hidden`}
      >
        {/* Logo */}
        <div className={`p-5 border-b border-slate-700 ${!isOpen && 'lg:flex lg:justify-center'}`}>
          {isOpen ? (
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-600 rounded-xl flex items-center justify-center text-xl">
                🏥
              </div>
              <div>
                <h1 className="font-bold text-lg">صيدلية مصر</h1>
                <p className="text-slate-400 text-xs">لوحة التحكم</p>
              </div>
            </div>
          ) : (
            <div className="w-10 h-10 bg-green-600 rounded-xl flex items-center justify-center text-xl">
              🏥
            </div>
          )}
        </div>

        {/* Navigation */}
        <nav className="p-4 space-y-2">
          {menuItems.map(item => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all ${
                currentPage === item.id
                  ? 'bg-green-600 text-white'
                  : 'hover:bg-slate-700 text-slate-300'
              } ${!isOpen && 'lg:justify-center lg:p-3'}`}
            >
              <span className="text-xl">{item.icon}</span>
              {isOpen && <span className="font-medium">{item.label}</span>}
            </button>
          ))}
        </nav>

        {/* Logout */}
        <div className="absolute bottom-0 right-0 left-0 p-4 border-t border-slate-700">
          <button
            onClick={onLogout}
            className={`w-full flex items-center gap-3 p-3 rounded-xl hover:bg-red-600 transition-all text-red-400 hover:text-white ${
              !isOpen && 'lg:justify-center'
            }`}
          >
            <span className="text-xl">🚪</span>
            {isOpen && <span className="font-medium">تسجيل الخروج</span>}
          </button>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;