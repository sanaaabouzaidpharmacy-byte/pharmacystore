import React, { useState } from 'react';

interface User {
  id: number;
  name: string;
  email: string;
  phone: string;
  orders: number;
  totalSpent: number;
  joinDate: string;
  status: 'active' | 'inactive';
}

const UsersPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  const [users] = useState<User[]>([
    { id: 1, name: 'محمد أحمد', email: 'mohamed@email.com', phone: '01012345678', orders: 12, totalSpent: 4500, joinDate: '2024-01-15', status: 'active' },
    { id: 2, name: 'فاطمة علي', email: 'fatma@email.com', phone: '01123456789', orders: 8, totalSpent: 3200, joinDate: '2024-01-10', status: 'active' },
    { id: 3, name: 'أحمد خالد', email: 'ahmed@email.com', phone: '01234567890', orders: 5, totalSpent: 1800, joinDate: '2024-01-08', status: 'active' },
    { id: 4, name: 'سارة محمود', email: 'sara@email.com', phone: '01567890123', orders: 15, totalSpent: 6500, joinDate: '2024-01-05', status: 'active' },
    { id: 5, name: 'عمر يوسف', email: 'omar@email.com', phone: '01678901234', orders: 3, totalSpent: 950, joinDate: '2024-01-01', status: 'inactive' },
  ]);

  const filteredUsers = users.filter(user =>
    user.name.includes(searchTerm) ||
    user.email.includes(searchTerm) ||
    user.phone.includes(searchTerm)
  );

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">المستخدمين</h1>
          <p className="text-slate-500 mt-1">إدارة بيانات العملاء</p>
        </div>
        <button className="bg-green-600 text-white px-6 py-3 rounded-xl font-medium hover:bg-green-700 transition-colors flex items-center gap-2">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          إضافة مستخدم
        </button>
      </div>

      {/* Search */}
      <div className="bg-white rounded-2xl p-4 shadow-sm">
        <div className="relative">
          <svg className="w-5 h-5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input
            type="text"
            placeholder="ابحث عن مستخدم..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pr-10 pl-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500"
          />
        </div>
      </div>

      {/* Users Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredUsers.map(user => (
          <div
            key={user.id}
            className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-lg transition-all cursor-pointer"
            onClick={() => setSelectedUser(user)}
          >
            {/* Avatar & Status */}
            <div className="flex items-center justify-between mb-4">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center text-3xl">
                👤
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                user.status === 'active' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
              }`}>
                {user.status === 'active' ? 'نشط' : 'غير نشط'}
              </span>
            </div>

            {/* User Info */}
            <h3 className="font-bold text-slate-800 text-lg mb-1">{user.name}</h3>
            <p className="text-slate-500 text-sm mb-4">{user.email}</p>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div className="text-center p-3 bg-slate-50 rounded-xl">
                <p className="text-2xl font-bold text-slate-800">{user.orders}</p>
                <p className="text-slate-500 text-xs">طلبات</p>
              </div>
              <div className="text-center p-3 bg-slate-50 rounded-xl">
                <p className="text-2xl font-bold text-green-600">{user.totalSpent.toLocaleString()}</p>
                <p className="text-slate-500 text-xs">المصروف</p>
              </div>
              <div className="text-center p-3 bg-slate-50 rounded-xl">
                <p className="text-2xl font-bold text-slate-800">{new Date(user.joinDate).toLocaleDateString('ar-EG', { month: 'short' })}</p>
                <p className="text-slate-500 text-xs">انضم</p>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              <button className="flex-1 bg-slate-100 text-slate-600 py-2 rounded-xl font-medium hover:bg-slate-200 transition-colors text-sm">
                عرض التفاصيل
              </button>
              <button className="p-2 hover:bg-red-100 rounded-xl transition-colors">
                <svg className="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {filteredUsers.length === 0 && (
        <div className="bg-white rounded-2xl p-12 text-center shadow-sm">
          <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center text-4xl mx-auto mb-4">
            👥
          </div>
          <h3 className="text-xl font-bold text-slate-800 mb-2">لا توجد مستخدمين</h3>
          <p className="text-slate-500">لم يتم العثور على مستخدمين مطابقين للبحث</p>
        </div>
      )}

      {/* User Details Modal */}
      {selectedUser && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-slate-800">تفاصيل المستخدم</h2>
              <button onClick={() => setSelectedUser(null)} className="p-2 hover:bg-slate-100 rounded-lg">
                <svg className="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="text-center mb-6">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center text-4xl mx-auto mb-3">
                👤
              </div>
              <h3 className="text-xl font-bold text-slate-800">{selectedUser.name}</h3>
              <span className={`px-3 py-1 rounded-full text-xs font-medium mt-2 inline-block ${
                selectedUser.status === 'active' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
              }`}>
                {selectedUser.status === 'active' ? 'نشط' : 'غير نشط'}
              </span>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
                <span className="text-slate-500">البريد الإلكتروني</span>
                <span className="font-medium text-slate-800">{selectedUser.email}</span>
              </div>
              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
                <span className="text-slate-500">رقم الهاتف</span>
                <span className="font-medium text-slate-800">{selectedUser.phone}</span>
              </div>
              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
                <span className="text-slate-500">عدد الطلبات</span>
                <span className="font-medium text-slate-800">{selectedUser.orders}</span>
              </div>
              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
                <span className="text-slate-500">إجمالي المصروف</span>
                <span className="font-medium text-green-600">{selectedUser.totalSpent.toLocaleString()} ج.م</span>
              </div>
              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
                <span className="text-slate-500">تاريخ الانضمام</span>
                <span className="font-medium text-slate-800">{selectedUser.joinDate}</span>
              </div>
            </div>

            <div className="flex gap-4 mt-6">
              <button className="flex-1 bg-slate-100 text-slate-600 py-3 rounded-xl font-medium hover:bg-slate-200 transition-colors">
                إغلاق
              </button>
              <button className="flex-1 bg-green-600 text-white py-3 rounded-xl font-medium hover:bg-green-700 transition-colors">
                تعديل البيانات
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UsersPage;