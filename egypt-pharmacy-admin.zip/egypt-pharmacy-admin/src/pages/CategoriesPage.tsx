import React, { useState } from 'react';

interface Category {
  id: number;
  name: string;
  nameAr: string;
  icon: string;
  productCount: number;
  status: 'active' | 'inactive';
  color: string;
}

const CategoriesPage: React.FC = () => {
  const [showAddModal, setShowAddModal] = useState(false);

  const [categories] = useState<Category[]>([
    { id: 1, name: 'Medicines', nameAr: 'أدوية', icon: '💊', productCount: 45, status: 'active', color: 'bg-red-50' },
    { id: 2, name: 'Cosmetics', nameAr: 'مستحضرات تجميل', icon: '💄', productCount: 38, status: 'active', color: 'bg-pink-50' },
    { id: 3, name: 'Hair Care', nameAr: 'عناية بالشعر', icon: '🧴', productCount: 22, status: 'active', color: 'bg-purple-50' },
    { id: 4, name: 'Skin Care', nameAr: 'عناية بالبشرة', icon: '✨', productCount: 28, status: 'active', color: 'bg-blue-50' },
    { id: 5, name: 'Vitamins', nameAr: 'فيتامينات', icon: '🌿', productCount: 15, status: 'active', color: 'bg-green-50' },
    { id: 6, name: 'Baby Care', nameAr: 'عناية بالأطفال', icon: '🍼', productCount: 12, status: 'inactive', color: 'bg-yellow-50' },
  ]);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">الأقسام</h1>
          <p className="text-slate-500 mt-1">إدارة أقسام المنتجات</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="bg-green-600 text-white px-6 py-3 rounded-xl font-medium hover:bg-green-700 transition-colors flex items-center gap-2"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          إضافة قسم
        </button>
      </div>

      {/* Categories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map(category => (
          <div key={category.id} className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-lg transition-all">
            <div className="flex items-start justify-between mb-4">
              <div className={`w-16 h-16 ${category.color} rounded-2xl flex items-center justify-center text-4xl`}>
                {category.icon}
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                category.status === 'active' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
              }`}>
                {category.status === 'active' ? 'نشط' : 'غير نشط'}
              </span>
            </div>

            <h3 className="font-bold text-slate-800 text-xl mb-1">{category.nameAr}</h3>
            <p className="text-slate-500 text-sm mb-4">{category.name}</p>

            <div className="flex items-center justify-between pt-4 border-t border-slate-100">
              <div className="flex items-center gap-2">
                <span className="text-slate-500 text-sm">عدد المنتجات</span>
                <span className="bg-slate-100 px-2 py-1 rounded-full text-sm font-bold text-slate-800">
                  {category.productCount}
                </span>
              </div>
              <div className="flex gap-2">
                <button className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
                  <svg className="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                  </svg>
                </button>
                <button className="p-2 hover:bg-red-100 rounded-lg transition-colors">
                  <svg className="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Category Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-slate-800">إضافة قسم جديد</h2>
              <button onClick={() => setShowAddModal(false)} className="p-2 hover:bg-slate-100 rounded-lg">
                <svg className="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <form className="space-y-4">
              <div>
                <label className="block text-slate-700 font-medium mb-2">اسم القسم (عربي)</label>
                <input type="text" className="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500" placeholder="أدخل اسم القسم" />
              </div>
              <div>
                <label className="block text-slate-700 font-medium mb-2">اسم القسم (إنجليزي)</label>
                <input type="text" className="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500" placeholder="Enter category name" />
              </div>
              <div>
                <label className="block text-slate-700 font-medium mb-2">الأيقونة</label>
                <div className="flex gap-3 flex-wrap">
                  {['💊', '💄', '🧴', '✨', '🌿', '🍼', '🧼', '💆'].map(icon => (
                    <button key={icon} type="button" className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center text-2xl hover:bg-green-100 transition-colors">
                      {icon}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex gap-4 pt-4">
                <button type="button" onClick={() => setShowAddModal(false)} className="flex-1 bg-slate-100 text-slate-600 py-3 rounded-xl font-medium hover:bg-slate-200 transition-colors">
                  إلغاء
                </button>
                <button type="submit" className="flex-1 bg-green-600 text-white py-3 rounded-xl font-medium hover:bg-green-700 transition-colors">
                  إضافة القسم
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default CategoriesPage;