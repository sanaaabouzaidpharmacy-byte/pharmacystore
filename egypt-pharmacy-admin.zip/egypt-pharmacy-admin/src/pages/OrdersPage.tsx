import React, { useState } from 'react';

interface Order {
  id: string;
  customer: string;
  phone: string;
  items: number;
  total: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  date: string;
}

const OrdersPage: React.FC = () => {
  const [selectedStatus, setSelectedStatus] = useState('all');

  const [orders] = useState<Order[]>([
    { id: 'ORD-001', customer: 'محمد أحمد', phone: '01012345678', items: 3, total: 450, status: 'delivered', date: '2024-01-15' },
    { id: 'ORD-002', customer: 'فاطمة علي', phone: '01123456789', items: 5, total: 850, status: 'shipped', date: '2024-01-15' },
    { id: 'ORD-003', customer: 'أحمد خالد', phone: '01234567890', items: 2, total: 320, status: 'processing', date: '2024-01-14' },
    { id: 'ORD-004', customer: 'سارة محمود', phone: '01567890123', items: 4, total: 1200, status: 'pending', date: '2024-01-14' },
    { id: 'ORD-005', customer: 'عمر يوسف', phone: '01678901234', items: 1, total: 180, status: 'cancelled', date: '2024-01-13' },
  ]);

  const statuses = [
    { id: 'all', label: 'الكل', count: orders.length, color: 'bg-slate-500' },
    { id: 'pending', label: 'جديدة', count: orders.filter(o => o.status === 'pending').length, color: 'bg-blue-500' },
    { id: 'processing', label: 'قيد التجهيز', count: orders.filter(o => o.status === 'processing').length, color: 'bg-yellow-500' },
    { id: 'shipped', label: 'قيد التوصيل', count: orders.filter(o => o.status === 'shipped').length, color: 'bg-purple-500' },
    { id: 'delivered', label: 'مكتملة', count: orders.filter(o => o.status === 'delivered').length, color: 'bg-green-500' },
    { id: 'cancelled', label: 'ملغاة', count: orders.filter(o => o.status === 'cancelled').length, color: 'bg-red-500' },
  ];

  const getStatusLabel = (status: Order['status']) => {
    const labels: Record<Order['status'], string> = {
      pending: 'جديدة',
      processing: 'قيد التجهيز',
      shipped: 'قيد التوصيل',
      delivered: 'مكتملة',
      cancelled: 'ملغاة',
    };
    return labels[status];
  };

  const getStatusColor = (status: Order['status']) => {
    const colors: Record<Order['status'], string> = {
      pending: 'bg-blue-100 text-blue-600',
      processing: 'bg-yellow-100 text-yellow-600',
      shipped: 'bg-purple-100 text-purple-600',
      delivered: 'bg-green-100 text-green-600',
      cancelled: 'bg-red-100 text-red-600',
    };
    return colors[status];
  };

  const filteredOrders = selectedStatus === 'all'
    ? orders
    : orders.filter(o => o.status === selectedStatus);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">الطلبات</h1>
          <p className="text-slate-500 mt-1">إدارة ومتابعة الطلبات</p>
        </div>
      </div>

      {/* Status Tabs */}
      <div className="bg-white rounded-2xl p-4 shadow-sm">
        <div className="flex gap-3 overflow-x-auto">
          {statuses.map(status => (
            <button
              key={status.id}
              onClick={() => setSelectedStatus(status.id)}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-colors whitespace-nowrap ${
                selectedStatus === status.id
                  ? 'bg-slate-800 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <div className={`w-3 h-3 rounded-full ${status.color}`}></div>
              <span>{status.label}</span>
              <span className={`px-2 py-1 rounded-full text-xs ${
                selectedStatus === status.id ? 'bg-white/20' : 'bg-slate-200'
              }`}>
                {status.count}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Orders List */}
      <div className="space-y-4">
        {filteredOrders.map(order => (
          <div key={order.id} className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              {/* Order Info */}
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-slate-100 rounded-xl flex items-center justify-center text-2xl">
                  📦
                </div>
                <div>
                  <p className="font-bold text-slate-800 text-lg">{order.id}</p>
                  <p className="text-slate-500 text-sm">{order.date}</p>
                </div>
              </div>

              {/* Customer Info */}
              <div className="flex items-center gap-6">
                <div>
                  <p className="text-slate-500 text-sm">العميل</p>
                  <p className="font-medium text-slate-800">{order.customer}</p>
                  <p className="text-slate-500 text-sm">{order.phone}</p>
                </div>
                <div>
                  <p className="text-slate-500 text-sm">عدد المنتجات</p>
                  <p className="font-medium text-slate-800">{order.items} منتج</p>
                </div>
                <div>
                  <p className="text-slate-500 text-sm">الإجمالي</p>
                  <p className="font-bold text-green-600 text-lg">{order.total.toLocaleString()} ج.م</p>
                </div>
              </div>

              {/* Status & Actions */}
              <div className="flex items-center gap-4">
                <span className={`px-4 py-2 rounded-full text-sm font-medium ${getStatusColor(order.status)}`}>
                  {getStatusLabel(order.status)}
                </span>
                <button className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
                  <svg className="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                  </svg>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {filteredOrders.length === 0 && (
        <div className="bg-white rounded-2xl p-12 text-center shadow-sm">
          <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center text-4xl mx-auto mb-4">
            📦
          </div>
          <h3 className="text-xl font-bold text-slate-800 mb-2">لا توجد طلبات</h3>
          <p className="text-slate-500">لم يتم العثور على طلبات في هذا التصنيف</p>
        </div>
      )}
    </div>
  );
};

export default OrdersPage;