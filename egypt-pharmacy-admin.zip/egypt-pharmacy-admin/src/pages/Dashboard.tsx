import React from 'react';

const Dashboard: React.FC = () => {
  // Statistics Cards
  const stats = [
    { label: 'إجمالي المبيعات', value: '125,450', change: '+12.5%', icon: '💰', color: 'from-green-500 to-green-600' },
    { label: 'عدد الطلبات', value: '1,234', change: '+8.2%', icon: '📦', color: 'from-blue-500 to-blue-600' },
    { label: 'عدد المستخدمين', value: '3,567', change: '+15.3%', icon: '👥', color: 'from-purple-500 to-purple-600' },
    { label: 'المنتجات', value: '156', change: '+5.1%', icon: '💊', color: 'from-orange-500 to-orange-600' },
  ];

  // Sales Data
  const salesData = [
    { month: 'يناير', sales: 12000, percentage: 43 },
    { month: 'فبراير', sales: 15000, percentage: 54 },
    { month: 'مارس', sales: 18000, percentage: 64 },
    { month: 'أبريل', sales: 22000, percentage: 79 },
    { month: 'مايو', sales: 25000, percentage: 89 },
    { month: 'يونيو', sales: 28000, percentage: 100 },
  ];

  // Orders by Status
  const ordersStatus = [
    { name: 'مكتملة', value: 850, color: '#22c55e' },
    { name: 'قيد التوصيل', value: 320, color: '#3b82f6' },
    { name: 'قيد التجهيز', value: 150, color: '#f59e0b' },
    { name: 'ملغاة', value: 30, color: '#ef4444' },
  ];

  const totalOrders = ordersStatus.reduce((sum, item) => sum + item.value, 0);

  // Top Products
  const topProducts = [
    { name: 'بانادول إكسترا', sales: 450, revenue: '12,750' },
    { name: 'بروفين 400', sales: 380, revenue: '8,360' },
    { name: 'لاروش بوزاي', sales: 290, revenue: '93,100' },
    { name: 'كايراستاز', sales: 180, revenue: '81,000' },
  ];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">لوحة التحكم</h1>
          <p className="text-slate-500 mt-1">نظرة عامة على أداء التطبيق</p>
        </div>
        <button className="bg-green-600 text-white px-4 py-2 rounded-xl font-medium hover:bg-green-700 transition-colors flex items-center gap-2">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          إضافة منتج جديد
        </button>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className={`bg-gradient-to-l ${stat.color} rounded-2xl p-6 text-white`}>
            <div className="flex items-center justify-between mb-4">
              <span className="text-3xl">{stat.icon}</span>
              <span className="bg-white/20 px-2 py-1 rounded-full text-sm">
                {stat.change}
              </span>
            </div>
            <p className="text-3xl font-bold">{stat.value}</p>
            <p className="text-white/80 mt-1">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sales Chart */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <h3 className="font-bold text-slate-800 mb-4">المبيعات الشهرية</h3>
          <div className="space-y-4">
            {salesData.map((item, index) => (
              <div key={index}>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm text-slate-600">{item.month}</span>
                  <span className="text-sm font-medium text-slate-800">{item.sales.toLocaleString()} ج.م</span>
                </div>
                <div className="h-4 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-l from-green-500 to-green-600 rounded-full transition-all duration-500"
                    style={{ width: `${item.percentage}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Orders Status */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <h3 className="font-bold text-slate-800 mb-4">حالة الطلبات</h3>
          <div className="flex items-center">
            {/* Simple Pie Chart Visualization */}
            <div className="relative w-40 h-40 flex-shrink-0">
              <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
                {(() => {
                  let currentAngle = 0;
                  return ordersStatus.map((item, index) => {
                    const percentage = (item.value / totalOrders) * 100;
                    const angle = (percentage / 100) * 360;
                    const startAngle = currentAngle;
                    currentAngle += angle;
                    const x1 = 50 + 40 * Math.cos((Math.PI * startAngle) / 180);
                    const y1 = 50 + 40 * Math.sin((Math.PI * startAngle) / 180);
                    const x2 = 50 + 40 * Math.cos((Math.PI * (startAngle + angle)) / 180);
                    const y2 = 50 + 40 * Math.sin((Math.PI * (startAngle + angle)) / 180);
                    const largeArc = angle > 180 ? 1 : 0;
                    return (
                      <path
                        key={index}
                        d={`M 50 50 L ${x1} ${y1} A 40 40 0 ${largeArc} 1 ${x2} ${y2} Z`}
                        fill={item.color}
                      />
                    );
                  });
                })()}
              </svg>
            </div>
            <div className="w-1/2 space-y-3 mr-6">
              {ordersStatus.map((item, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
                    <span className="text-slate-600">{item.name}</span>
                  </div>
                  <span className="font-bold text-slate-800">{item.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Products */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <h3 className="font-bold text-slate-800 mb-4">المنتجات الأكثر مبيعاً</h3>
          <div className="space-y-4">
            {topProducts.map((product, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-green-600 font-bold">
                    {index + 1}
                  </span>
                  <span className="font-medium text-slate-800">{product.name}</span>
                </div>
                <div className="text-left">
                  <p className="font-bold text-green-600">{product.revenue} ج.م</p>
                  <p className="text-slate-500 text-sm">{product.sales} عملية بيع</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Orders */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-slate-800">أحدث الطلبات</h3>
            <button className="text-green-600 text-sm hover:underline">عرض الكل</button>
          </div>
          <div className="space-y-3">
            {[
              { id: 'ORD-001', customer: 'محمد أحمد', total: '450', status: 'مكتمل', statusColor: 'bg-green-100 text-green-600' },
              { id: 'ORD-002', customer: 'فاطمة علي', total: '850', status: 'قيد التوصيل', statusColor: 'bg-blue-100 text-blue-600' },
              { id: 'ORD-003', customer: 'أحمد خالد', total: '320', status: 'قيد التجهيز', statusColor: 'bg-yellow-100 text-yellow-600' },
              { id: 'ORD-004', customer: 'سارة محمود', total: '1,200', status: 'قيد التوصيل', statusColor: 'bg-blue-100 text-blue-600' },
            ].map((order, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-slate-200 rounded-full flex items-center justify-center">
                    👤
                  </div>
                  <div>
                    <p className="font-medium text-slate-800">{order.customer}</p>
                    <p className="text-slate-500 text-sm">{order.id}</p>
                  </div>
                </div>
                <div className="text-left">
                  <p className="font-bold text-slate-800">{order.total} ج.م</p>
                  <span className={`text-xs px-2 py-1 rounded-full ${order.statusColor}`}>
                    {order.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;