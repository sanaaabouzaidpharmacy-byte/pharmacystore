export interface Product {
  id: number;
  name: string;
  nameAr: string;
  price: number;
  originalPrice?: number;
  category: 'medicine' | 'cosmetics';
  subcategory: string;
  description: string;
  manufacturer: string;
  image: string;
  inStock: boolean;
  requiresPrescription?: boolean;
  activeIngredient?: string;
  dosage?: string;
}

export const products: Product[] = [
  // ======== المسكنات والأدوية العامة ========
  {
    id: 1,
    name: 'Panadol Extra 500mg',
    nameAr: 'بانادول إكسترا 500 مجم',
    price: 28.50,
    originalPrice: 35.00,
    category: 'medicine',
    subcategory: 'مسكنات',
    description: 'مسكن للصداع وآلام الجسم وخافض للحرارة. يحتوي على باراسيتامول 500 مجم وكافيين 65 مجم',
    manufacturer: 'جلاسكو سميثكلاين',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c47f2534?w=400',
    inStock: true,
    activeIngredient: 'باراسيتامول + كافيين',
    dosage: 'قرص واحد كل 4-6 ساعات'
  },
  {
    id: 2,
    name: 'Brufen 400mg',
    nameAr: 'بروفين 400 مجم',
    price: 22.00,
    category: 'medicine',
    subcategory: 'مسكنات',
    description: 'مضاد التهاب ومسكن قوي. يحتوي على إيبوبروفين 400 مجم',
    manufacturer: 'ABBOTT',
    image: 'https://images.unsplash.com/photo-1550572017-edd951aa8f72?w=400',
    inStock: true,
    activeIngredient: 'إيبوبروفين 400 مجم',
    dosage: 'قرص كل 6-8 ساعات'
  },
  {
    id: 3,
    name: 'Adol 500mg',
    nameAr: 'أدول 500 مجم',
    price: 15.00,
    category: 'medicine',
    subcategory: 'مسكنات',
    description: 'مسكن وخافض حرارة فعال وآمن',
    manufacturer: ' Memphis',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c47f2534?w=400',
    inStock: true,
    activeIngredient: 'باراسيتامول 500 مجم',
    dosage: 'قرص كل 6 ساعات'
  },
  {
    id: 4,
    name: 'Naproxen 250mg',
    nameAr: 'نابروكسين 250 مجم',
    price: 35.00,
    category: 'medicine',
    subcategory: 'مسكنات',
    description: 'مسكن ومضاد التهاب للاستخدام中长期',
    manufacturer: '诺华制药',
    image: 'https://images.unsplash.com/photo-1550572017-edd951aa8f72?w=400',
    inStock: true,
    activeIngredient: 'نابروكسين صوديوم 250 مجم'
  },
  {
    id: 5,
    name: 'Catafast 50mg',
    nameAr: 'كاتافاست 50 مجم',
    price: 45.00,
    category: 'medicine',
    subcategory: 'مسكنات',
    description: 'مسكن قوي سريع المفعول للصداع النصفي وآلام المفاصل',
    manufacturer: ' Novartis',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c47f2534?w=400',
    inStock: true,
    activeIngredient: 'ديكلوفيناك بوتاسيوم 50 مجم',
    requiresPrescription: false
  },

  // ======== أدوية البرد والإنفلونزا ========
  {
    id: 6,
    name: 'Coldaway Sachet',
    nameAr: 'كولد أواي ساشيت',
    price: 32.00,
    originalPrice: 40.00,
    category: 'medicine',
    subcategory: 'برد وإنفلونزا',
    description: 'علاج أعراض البرد والإنفلونزا والاحتقان والحمى',
    manufacturer: 'مختبرات ميدفارم',
    image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400',
    inStock: true,
    activeIngredient: 'باراسيتامول + سودوإيفيدرين + فينيليفرين'
  },
  {
    id: 7,
    name: 'Fluor Sensitive',
    nameAr: 'فلور سينسيتف',
    price: 65.00,
    category: 'medicine',
    subcategory: 'برد وإنفلونزا',
    description: 'مزيل للاحتقان ومضاد الهيستامين',
    manufacturer: 'سانوفي',
    image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400',
    inStock: true
  },
  {
    id: 8,
    name: 'Actifed',
    nameAr: 'أكتيفيد',
    price: 28.00,
    category: 'medicine',
    subcategory: 'برد وإنفلونزا',
    description: 'مزيل احتقان الأنف والجيوب الأنفية',
    manufacturer: 'جونسون آند جونسون',
    image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400',
    inStock: true
  },
  {
    id: 9,
    name: 'T-antiflu',
    nameAr: 'تي أنتیفلو',
    price: 38.00,
    category: 'medicine',
    subcategory: 'برد وإنفلونزا',
    description: 'علاج شامل لأعراض البرد والإنفلونزا',
    manufacturer: 'مختبرات أسترا',
    image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400',
    inStock: true
  },
  {
    id: 10,
    name: 'Sinomax',
    nameAr: 'سينوماكس',
    price: 42.00,
    category: 'medicine',
    subcategory: 'برد وإنفلونزا',
    description: 'علاج فعال للاحتقان والصداع والحرارة',
    manufacturer: 'MDB Pharma',
    image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400',
    inStock: true
  },

  // ======== أدوية الجهاز الهضمي ========
  {
    id: 11,
    name: 'Omeprazole 20mg',
    nameAr: 'أوميبرازول 20 مجم',
    price: 25.00,
    originalPrice: 32.00,
    category: 'medicine',
    subcategory: 'جهاز هضمي',
    description: 'علاج الحموضة والقرحة المعدية وعلاج ارتجاع المريء',
    manufacturer: 'إبيكاد فارما',
    image: 'https://images.unsplash.com/photo-1559726224-1e69c4bef0f4?w=400',
    inStock: true,
    activeIngredient: 'أوميبرازول 20 مجم',
    requiresPrescription: false
  },
  {
    id: 12,
    name: 'Ranitidine 150mg',
    nameAr: 'رانيتيدين 150 مجم',
    price: 18.00,
    category: 'medicine',
    subcategory: 'جهاز هضمي',
    description: 'علاج الحموضة وقرحة المعدة والاثني عشر',
    manufacturer: 'جامكو',
    image: 'https://images.unsplash.com/photo-1559726224-1e69c4bef0f4?w=400',
    inStock: true,
    activeIngredient: 'رانيتيدين هيدروكلوريد 150 مجم'
  },
  {
    id: 13,
    name: 'Motilium 10mg',
    nameAr: 'موتيليوم 10 مجم',
    price: 55.00,
    originalPrice: 68.00,
    category: 'medicine',
    subcategory: 'جهاز هضمي',
    description: 'علاج الغثيان والقيء وعسر الهضم',
    manufacturer: 'جانسن',
    image: 'https://images.unsplash.com/photo-1559726224-1e69c4bef0f4?w=400',
    inStock: true,
    activeIngredient: 'دومبيريدون 10 مجم'
  },
  {
    id: 14,
    name: 'Buscopan',
    nameAr: 'بسكوبان',
    price: 38.00,
    category: 'medicine',
    subcategory: 'جهاز هضمي',
    description: 'مضاد للتشنجات المعدية والأمعائية',
    manufacturer: 'بوهرينجر إنجلهايم',
    image: 'https://images.unsplash.com/photo-1559726224-1e69c4bef0f4?w=400',
    inStock: true
  },
  {
    id: 15,
    name: 'Normak Bent',
    nameAr: 'نورماك بينت',
    price: 30.00,
    category: 'medicine',
    subcategory: 'جهاز هضمي',
    description: 'علاج الإسهال والتقلصات المعوية',
    manufacturer: 'مختبرات مالين',
    image: 'https://images.unsplash.com/photo-1559726224-1e69c4bef0f4?w=400',
    inStock: true
  },

  // ======== الفيتامينات والمكملات ========
  {
    id: 16,
    name: 'Supradyn',
    nameAr: 'سوبراداين',
    price: 85.00,
    originalPrice: 110.00,
    category: 'medicine',
    subcategory: 'فيتامينات',
    description: 'مكمل غذائي شامل يحتوي على فيتامينات ومعادن أساسية',
    manufacturer: 'BAYER',
    image: 'https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=400',
    inStock: true
  },
  {
    id: 17,
    name: 'Centrum',
    nameAr: 'سينتروم',
    price: 120.00,
    category: 'medicine',
    subcategory: 'فيتامينات',
    description: 'فيتامينات شاملة للرجال والنساء',
    manufacturer: 'Pfizer',
    image: 'https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=400',
    inStock: true
  },
  {
    id: 18,
    name: 'D drops',
    nameAr: 'دي درابر',
    price: 45.00,
    category: 'medicine',
    subcategory: 'فيتامينات',
    description: 'فيتامين د3 للكالسيوم والمناعة',
    manufacturer: 'جينزايرم',
    image: 'https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=400',
    inStock: true
  },
  {
    id: 19,
    name: 'B-Complex',
    nameAr: 'بي كومبلكس',
    price: 35.00,
    category: 'medicine',
    subcategory: 'فيتامينات',
    description: 'فيتامينات ب المركبة للأعصاب والجلد',
    manufacturer: 'NOVARTIS',
    image: 'https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=400',
    inStock: true
  },
  {
    id: 20,
    name: 'Feroglobin',
    nameAr: 'فيروغلوبين',
    price: 75.00,
    originalPrice: 90.00,
    category: 'medicine',
    subcategory: 'فيتامينات',
    description: 'مكمل الحديد والفيتامينات لفقر الدم',
    manufacturer: 'فيتيبيشن',
    image: 'https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=400',
    inStock: true
  },

  // ======== أدوية الحساسية ========
  {
    id: 21,
    name: ' cetirizine',
    nameAr: 'سيتريزين',
    price: 20.00,
    category: 'medicine',
    subcategory: 'حساسية',
    description: 'مضاد هيستامين علاج الحساسية والشرى',
    manufacturer: 'EPICO',
    image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400',
    inStock: true,
    activeIngredient: 'سيتريزين هيدروكلوريد 10 مجم'
  },
  {
    id: 22,
    name: 'Loratadine 10mg',
    nameAr: 'لوراتادين 10 مجم',
    price: 18.00,
    category: 'medicine',
    subcategory: 'حساسية',
    description: 'مضاد هيستامين غير منفصل',
    manufacturer: 'جالينكا',
    image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400',
    inStock: true,
    activeIngredient: 'لوراتادين 10 مجم'
  },
  {
    id: 23,
    name: 'Telfast 120mg',
    nameAr: 'تلفاست 120 مجم',
    price: 48.00,
    category: 'medicine',
    subcategory: 'حساسية',
    description: 'علاج قوي للحساسية الموسمية',
    manufacturer: 'سانوفي',
    image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400',
    inStock: true
  },

  // ======== المضادات الحيوية ========
  {
    id: 24,
    name: 'Augmentin 1g',
    nameAr: 'أوجمنتين 1 جرام',
    price: 95.00,
    category: 'medicine',
    subcategory: 'مضادات حيوية',
    description: 'مضاد حيوي واسع المدى',
    manufacturer: 'GSK',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c47f2534?w=400',
    inStock: true,
    requiresPrescription: true,
    activeIngredient: 'أموكسيسيلين + كلافيولانيك أسيد'
  },
  {
    id: 25,
    name: 'Azithromycin 500mg',
    nameAr: 'أزيثرومايسين 500 مجم',
    price: 85.00,
    category: 'medicine',
    subcategory: 'مضادات حيوية',
    description: 'مضاد حيوي للعدوى التنفسية',
    manufacturer: 'جي زد اف بي',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c47f2534?w=400',
    inStock: true,
    requiresPrescription: true
  },
  {
    id: 26,
    name: 'Ciproxin 500mg',
    nameAr: 'سيبروكسين 500 مجم',
    price: 65.00,
    category: 'medicine',
    subcategory: 'مضادات حيوية',
    description: 'مضاد حيوي للعدوى البكتيرية',
    manufacturer: 'BAYER',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c47f2534?w=400',
    inStock: true,
    requiresPrescription: true
  },

  // ======== العناية بالبشرة ========
  {
    id: 27,
    name: 'La Roche-Posay Effaclar',
    nameAr: 'لاروش بوزاي إيفيكلار',
    price: 320.00,
    originalPrice: 380.00,
    category: 'cosmetics',
    subcategory: 'عناية بالبشرة',
    description: 'سيروم لتصحيح آثار الحبوب والمسامات',
    manufacturer: 'لاروش بوزاي',
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=400',
    inStock: true
  },
  {
    id: 28,
    name: 'Vichy Mineral 89',
    nameAr: 'فيشي مينرال 89',
    price: 285.00,
    category: 'cosmetics',
    subcategory: 'عناية بالبشرة',
    description: 'جل مركز يرطب ويرمم البشرة',
    manufacturer: 'فيشي',
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=400',
    inStock: true
  },
  {
    id: 29,
    name: 'CeraVe Hydrating Cleanser',
    nameAr: 'سيرافي هيدريتينج كلينزر',
    price: 195.00,
    category: 'cosmetics',
    subcategory: 'عناية بالبشرة',
    description: 'غسول منظف يرطب البشرة دون تجريدها',
    manufacturer: 'سيرافي',
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=400',
    inStock: true
  },
  {
    id: 30,
    name: 'Neutrogena Hydro Boost',
    nameAr: 'نيوتروجينا هايدرو بوست',
    price: 220.00,
    category: 'cosmetics',
    subcategory: 'عناية بالبشرة',
    description: 'مرطب مائي خفيف للاستخدام اليومي',
    manufacturer: 'نيوتروجينا',
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=400',
    inStock: true
  },
  {
    id: 31,
    name: 'Bioderma Sensibio',
    nameAr: 'بيوديرما سينسيبيو',
    price: 250.00,
    category: 'cosmetics',
    subcategory: 'عناية بالبشرة',
    description: 'سيروم مهدئ للبشرة الحساسة',
    manufacturer: 'بيوديرما',
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=400',
    inStock: true
  },

  // ======== مستحضرات الشعر ========
  {
    id: 32,
    name: 'Kérastase Elixir',
    nameAr: 'كيراستاز إيليكسي رويال',
    price: 450.00,
    originalPrice: 520.00,
    category: 'cosmetics',
    subcategory: 'عناية بالشعر',
    description: 'زيت سائل لعلاج الشعر التالف',
    manufacturer: 'كيراستاز',
    image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=400',
    inStock: true
  },
  {
    id: 33,
    name: 'L Oreal Elseve',
    nameAr: 'لوريال إلسيف',
    price: 120.00,
    category: 'cosmetics',
    subcategory: 'عناية بالشعر',
    description: 'سيروم مغذي للشعر الجاف والمتقصف',
    manufacturer: 'لوريال',
    image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=400',
    inStock: true
  },
  {
    id: 34,
    name: 'Pantene Pro-V',
    nameAr: 'بانتين برو-في',
    price: 95.00,
    category: 'cosmetics',
    subcategory: 'عناية بالشعر',
    description: 'شامبو برو-في لتقوية الشعر',
    manufacturer: 'بانتين',
    image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=400',
    inStock: true
  },
  {
    id: 35,
    name: 'Tresemme Keratin',
    nameAr: 'تريسيمي كيراتين',
    price: 135.00,
    category: 'cosmetics',
    subcategory: 'عناية بالشعر',
    description: 'سيروم كيراتين لتنعيم الشعر',
    manufacturer: 'تريسيمي',
    image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=400',
    inStock: true
  },

  // ======== المكياج ========
  {
    id: 36,
    name: 'Maybelline SuperStay',
    nameAr: 'مايبيلين سوبر ستاي',
    price: 180.00,
    originalPrice: 220.00,
    category: 'cosmetics',
    subcategory: 'مكياج',
    description: 'أحمر شفاه طويل الأمد يدوم 24 ساعة',
    manufacturer: 'مايبيلين',
    image: 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=400',
    inStock: true
  },
  {
    id: 37,
    name: 'L Oreal Infallible',
    nameAr: 'لوريال إنفاليبل',
    price: 195.00,
    category: 'cosmetics',
    subcategory: 'مكياج',
    description: 'مثبت ماكياج يدوم 24 ساعة',
    manufacturer: 'لوريال',
    image: 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=400',
    inStock: true
  },
  {
    id: 38,
    name: 'NYX Foundation',
    nameAr: 'إن واي إكس فاونديشن',
    price: 145.00,
    category: 'cosmetics',
    subcategory: 'مكياج',
    description: 'فاونديشن خفيف ومغطي',
    manufacturer: 'NYX',
    image: 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=400',
    inStock: true
  },
  {
    id: 39,
    name: 'Essence Lash Princess',
    nameAr: 'إسينس لاش برينسيس',
    price: 85.00,
    category: 'cosmetics',
    subcategory: 'مكياج',
    description: 'ماسكارا لرموش طويلة وكثيفة',
    manufacturer: 'إسينس',
    image: 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=400',
    inStock: true
  },
  {
    id: 40,
    name: 'CATRICE Concealer',
    nameAr: 'كاترايس كونسيالر',
    price: 110.00,
    category: 'cosmetics',
    subcategory: 'مكياج',
    description: 'كونسيالر للعيوب والهالات السوداء',
    manufacturer: 'كاترايس',
    image: 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=400',
    inStock: true
  },

  // ======== العناية بالعيون ========
  {
    id: 41,
    name: 'Vichy Liftactiv',
    nameAr: 'فيشي ليفتأكتيف',
    price: 380.00,
    category: 'cosmetics',
    subcategory: 'عناية بالعيون',
    description: 'كريم للعيون يقلل الهالات والانتفاخات',
    manufacturer: 'فيشي',
    image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400',
    inStock: true
  },
  {
    id: 42,
    name: 'La Roche-Posay Hydraphase',
    nameAr: 'لاروش بوزاي هيدرافاز',
    price: 290.00,
    category: 'cosmetics',
    subcategory: 'عناية بالعيون',
    description: 'كريم خفيف للعين يرطب وينعش',
    manufacturer: 'لاروش بوزاي',
    image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400',
    inStock: true
  },

  // ======== واقي الشمس ========
  {
    id: 43,
    name: 'La Roche-Posay Anthelios',
    nameAr: 'لاروش بوزاي أنثيليوس',
    price: 350.00,
    originalPrice: 400.00,
    category: 'cosmetics',
    subcategory: 'واقي شمس',
    description: ' واقي شمس SPF 50+ للبشرة الحساسة',
    manufacturer: 'لاروش بوزاي',
    image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400',
    inStock: true
  },
  {
    id: 44,
    name: 'Vichy Capital Soleil',
    nameAr: 'فيشي كابيتال سويل',
    price: 280.00,
    category: 'cosmetics',
    subcategory: 'واقي شمس',
    description: ' واقي شمس خفيف غير دهني SPF 30',
    manufacturer: 'فيشي',
    image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400',
    inStock: true
  },
  {
    id: 45,
    name: 'Neutrogena Ultra Sheer',
    nameAr: 'نيوتروجينا ألترا شير',
    price: 165.00,
    category: 'cosmetics',
    subcategory: 'واقي شمس',
    description: ' واقي شمس خفيف سريع الامتصاص SPF 70',
    manufacturer: 'نيوتروجينا',
    image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400',
    inStock: true
  },

  // ======== أدوية السكري والضغط ========
  {
    id: 46,
    name: 'Glucophage 500mg',
    nameAr: 'جلوكوفاج 500 مجم',
    price: 38.00,
    category: 'medicine',
    subcategory: 'سكري وضغط',
    description: 'علاج مرض السكري من النوع الثاني',
    manufacturer: ' ميرك',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c47f2534?w=400',
    inStock: true,
    requiresPrescription: true,
    activeIngredient: 'ميتفورمين هيدروكلوريد 500 مجم'
  },
  {
    id: 47,
    name: 'Losartan 50mg',
    nameAr: 'لوسارتان 50 مجم',
    price: 42.00,
    category: 'medicine',
    subcategory: 'سكري وضغط',
    description: 'علاج ارتفاع ضغط الدم',
    manufacturer: 'إيفا فارما',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c47f2534?w=400',
    inStock: true,
    requiresPrescription: true,
    activeIngredient: 'لوسارتان بوتاسيوم 50 مجم'
  },
  {
    id: 48,
    name: 'Amlodipine 5mg',
    nameAr: 'أملوديبين 5 مجم',
    price: 35.00,
    category: 'medicine',
    subcategory: 'سكري وضغط',
    description: 'حاصر قنوات الكالسيوم لارتفاع ضغط الدم',
    manufacturer: 'Norvasc',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c47f2534?w=400',
    inStock: true,
    requiresPrescription: true
  },

  // ======== العناية بالشفاه ========
  {
    id: 49,
    name: 'Carmol Classic',
    nameAr: 'كارمول كلاسيك',
    price: 25.00,
    category: 'cosmetics',
    subcategory: 'عناية بالشفاه',
    description: 'مرطب للشفاه مع زبدة الكاكاو',
    manufacturer: 'كارمول',
    image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400',
    inStock: true
  },
  {
    id: 50,
    name: 'Vaseline Lip Therapy',
    nameAr: 'فازلين ليس ثيرابي',
    price: 35.00,
    category: 'cosmetics',
    subcategory: 'عناية بالشفاه',
    description: 'جل واقي ومرطب للشفاه',
    manufacturer: 'فازلين',
    image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400',
    inStock: true
  },

  // ======== أدوية القلب ========
  {
    id: 51,
    name: 'Aspirin Cardio 100mg',
    nameAr: 'أسبرين كارديو 100 مجم',
    price: 28.00,
    category: 'medicine',
    subcategory: 'قلب وأوعية',
    description: 'وقاية من الجلطات والنوبات القلبية',
    manufacturer: 'BAYER',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c47f2534?w=400',
    inStock: true,
    requiresPrescription: true
  },
  {
    id: 52,
    name: 'Atorvastatin 20mg',
    nameAr: 'أتورفاستاتين 20 مجم',
    price: 65.00,
    category: 'medicine',
    subcategory: 'قلب وأوعية',
    description: 'خفض الكوليسترول الضار',
    manufacturer: 'إبيكاد',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c47f2534?w=400',
    inStock: true,
    requiresPrescription: true
  },

  // ======== العناية بالجسم ========
  {
    id: 53,
    name: 'Nivea Body Lotion',
    nameAr: 'نيفيا لوشن الجسم',
    price: 85.00,
    category: 'cosmetics',
    subcategory: 'عناية بالجسم',
    description: 'لوشن مرطب للبشرة الجافة',
    manufacturer: 'نيفيا',
    image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400',
    inStock: true
  },
  {
    id: 54,
    name: 'Dove Body Wash',
    nameAr: 'دوف غسول الجسم',
    price: 75.00,
    originalPrice: 95.00,
    category: 'cosmetics',
    subcategory: 'عناية بالجسم',
    description: 'غسول مرطب بالمياه',
    manufacturer: 'دوف',
    image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400',
    inStock: true
  },
  {
    id: 55,
    name: 'Garnier Body Treat',
    nameAr: 'غارنييه بودي تريت',
    price: 95.00,
    category: 'cosmetics',
    subcategory: 'عناية بالجسم',
    description: 'كريم مرطب غني بزيت الأركان',
    manufacturer: 'غارنييه',
    image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400',
    inStock: true
  },

  // ======== أدوية الأعصاب ========
  {
    id: 56,
    name: 'Neurontin 300mg',
    nameAr: 'نيورونتين 300 مجم',
    price: 85.00,
    category: 'medicine',
    subcategory: 'أعصاب',
    description: 'علاج الأعصاب والصرع',
    manufacturer: 'Pfizer',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c47f2534?w=400',
    inStock: true,
    requiresPrescription: true,
    activeIngredient: 'جابابنتين 300 مجم'
  },
  {
    id: 57,
    name: 'Dianeural',
    nameAr: 'ديانورال',
    price: 75.00,
    category: 'medicine',
    subcategory: 'أعصاب',
    description: 'علاج التهاب الأعصاب الطرفية',
    manufacturer: 'مختبرات إيفا',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c47f2534?w=400',
    inStock: true
  },

  // ======== أدوية العظام ========
  {
    id: 58,
    name: 'Osteocare',
    nameAr: 'أوستيوكير',
    price: 95.00,
    category: 'medicine',
    subcategory: 'عظام ومفاصل',
    description: 'مكمل غذائي للكالسيوم وصحة العظام',
    manufacturer: 'فيتيبيشن',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c47f2534?w=400',
    inStock: true
  },
  {
    id: 59,
    name: 'Moveflex',
    nameAr: 'موف فليكس',
    price: 120.00,
    originalPrice: 145.00,
    category: 'medicine',
    subcategory: 'عظام ومفاصل',
    description: 'جل موضعي لتسكين آلام المفاصل',
    manufacturer: 'ميبا',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c47f2534?w=400',
    inStock: true
  },
  {
    id: 60,
    name: 'Glucosamine',
    nameAr: 'جلوكوزأمين',
    price: 135.00,
    category: 'medicine',
    subcategory: 'عظام ومفاصل',
    description: 'دعم صحة المفاصل والغضاريف',
    manufacturer: 'نيو فارتيس',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c47f2534?w=400',
    inStock: true
  }
];

export const getProductsByCategory = (category: string): Product[] => {
  return products.filter(p => p.category === category);
};

export const getProductsBySubcategory = (subcategory: string): Product[] => {
  return products.filter(p => p.subcategory === subcategory);
};

export const searchProducts = (query: string): Product[] => {
  const lowerQuery = query.toLowerCase();
  return products.filter(p =>
    p.name.toLowerCase().includes(lowerQuery) ||
    p.nameAr.includes(query) ||
    p.description.includes(query)
  );
};

export const categories = [
  { id: 'medicine', name: 'أدوية', icon: '💊', subcategories: ['مسكنات', 'برد وإنفلونزا', 'جهاز هضمي', 'فيتامينات', 'حساسية', 'مضادات حيوية', 'سكري وضغط', 'قلب وأوعية', 'أعصاب', 'عظام ومفاصل'] },
  { id: 'cosmetics', name: 'مستحضرات تجميل', icon: '💄', subcategories: ['عناية بالبشرة', 'عناية بالشعر', 'مكياج', 'عناية بالعيون', 'واقي شمس', 'عناية بالشفاه', 'عناية بالجسم'] }
];