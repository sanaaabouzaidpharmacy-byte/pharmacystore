import React, { useState, useEffect } from 'react';
import { Product, searchProducts } from '../data/products';
import ProductCard from '../components/ProductCard';

interface SearchPageProps {
  query: string;
  onNavigate: (page: string, product?: Product) => void;
  onAddToCart: (product: Product) => void;
  products: Product[];
  onSearch: (query: string) => void;
}

const SearchPage: React.FC<SearchPageProps> = ({ query, onNavigate, onAddToCart, products, onSearch }) => {
  const [searchInput, setSearchInput] = useState(query);
  const [results, setResults] = useState<Product[]>([]);

  useEffect(() => {
    if (query) {
      setSearchInput(query);
      setResults(searchProducts(query));
    }
  }, [query]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      onSearch(searchInput);
      setResults(searchProducts(searchInput));
    }
  };

  const popularSearches = ['بانادول', 'بروفين', 'فيتامين', 'كريم واقي شمس', 'شامبو'];

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="bg-gradient-to-l from-green-800 to-green-600 text-white px-4 py-5">
        <h1 className="text-xl font-bold mb-4">البحث</h1>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="relative">
          <input
            type="text"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="ابحث عن دواء أو منتج..."
            className="w-full bg-white text-gray-800 rounded-full py-3 px-5 pr-12 text-right placeholder-gray-400 shadow-lg"
          />
          <button type="submit" className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </button>
        </form>
      </div>

      {/* Results or Suggestions */}
      {query ? (
        <div className="px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-bold text-gray-800">نتائج البحث</h2>
            <span className="text-gray-500 text-sm">{results.length} نتيجة</span>
          </div>

          {results.length > 0 ? (
            <div className="grid grid-cols-2 gap-3">
              {results.map(product => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onClick={() => onNavigate('product-details', product)}
                  onAddToCart={() => onAddToCart(product)}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-10">
              <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-5xl">🔍</span>
              </div>
              <h3 className="font-bold text-gray-800 mb-2">لا توجد نتائج</h3>
              <p className="text-gray-500 text-sm">جرب البحث بكلمات مختلفة</p>
            </div>
          )}
        </div>
      ) : (
        <div className="px-4 py-4">
          {/* Popular Searches */}
          <div className="mb-6">
            <h3 className="font-bold text-gray-800 mb-3">البحث الأكثر شيوعاً</h3>
            <div className="flex flex-wrap gap-2">
              {popularSearches.map(term => (
                <button
                  key={term}
                  onClick={() => {
                    setSearchInput(term);
                    onSearch(term);
                    setResults(searchProducts(term));
                  }}
                  className="bg-gray-100 text-gray-700 px-4 py-2 rounded-full text-sm hover:bg-green-100 hover:text-green-700 transition-colors"
                >
                  {term}
                </button>
              ))}
            </div>
          </div>

          {/* Categories Quick Access */}
          <div className="mb-6">
            <h3 className="font-bold text-gray-800 mb-3">تصفح حسب القسم</h3>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => onNavigate('categories')}
                className="bg-red-50 rounded-xl p-4 flex items-center gap-3 hover:bg-red-100 transition-colors"
              >
                <span className="text-3xl">💊</span>
                <span className="font-semibold text-gray-800">أدوية</span>
              </button>
              <button
                onClick={() => onNavigate('categories')}
                className="bg-pink-50 rounded-xl p-4 flex items-center gap-3 hover:bg-pink-100 transition-colors"
              >
                <span className="text-3xl">💄</span>
                <span className="font-semibold text-gray-800">تجميل</span>
              </button>
            </div>
          </div>

          {/* Recent Products */}
          <div>
            <h3 className="font-bold text-gray-800 mb-3">منتجات مميزة</h3>
            <div className="grid grid-cols-2 gap-3">
              {products.slice(0, 4).map(product => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onClick={() => onNavigate('product-details', product)}
                  onAddToCart={() => onAddToCart(product)}
                />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchPage;