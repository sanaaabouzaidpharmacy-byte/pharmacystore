import React, { useState } from 'react';

const ProfilePage: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const menuItems = [
    { icon: '📦', label: 'طلباتي', bg: 'bg-blue-50' },
    { icon: '📍', label: 'العناوين', bg: 'bg-green-50' },
    { icon: '💳', label: 'طرق الدفع', bg: 'bg-purple-50' },
    { icon: '🔔', label: 'الإشعارات', bg: 'bg-yellow-50' },
    { icon: '❤️', label: 'المفضلة', bg: 'bg-red-50' },
    { icon: '⚙️', label: 'الإعدادات', bg: 'bg-gray-50' },
    { icon: '❓', label: 'المساعدة', bg: 'bg-blue-50' },
    { icon: '📞', label: 'اتصل بنا', bg: 'bg-green-50' },
  ];

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="bg-gradient-to-l from-green-800 to-green-600 text-white px-4 py-5">
        <h1 className="text-xl font-bold">حسابي</h1>
      </div>

      {/* Profile Card */}
      <div className="px-4 py-5">
        {isLoggedIn ? (
          <div className="bg-white rounded-2xl p-5 shadow-sm flex items-center gap-4 mb-5">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
              <span className="text-3xl">👤</span>
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-gray-800">أحمد محمد</h3>
              <p className="text-gray-500 text-sm">ahmed@example.com</p>
            </div>
            <button className="text-green-600">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </button>
          </div>
        ) : (
          <div className="bg-gradient-to-l from-green-700 to-green-500 rounded-2xl p-6 text-white mb-5">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                <span className="text-4xl">👤</span>
              </div>
              <div>
                <h3 className="font-bold text-lg">مرحباً بك!</h3>
                <p className="text-green-100 text-sm">سجل دخولك لتجربة أفضل</p>
              </div>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setIsLoggedIn(true)}
                className="flex-1 bg-white text-green-600 py-3 rounded-xl font-semibold hover:bg-green-50 transition-colors"
              >
                تسجيل دخول
              </button>
              <button className="flex-1 bg-white/20 text-white py-3 rounded-xl font-semibold hover:bg-white/30 transition-colors">
                إنشاء حساب
              </button>
            </div>
          </div>
        )}

        {/* Menu Grid */}
        <div className="grid grid-cols-4 gap-3">
          {menuItems.map((item, index) => (
            <button
              key={index}
              className={`${item.bg} rounded-xl p-4 flex flex-col items-center gap-2 hover:shadow-md transition-shadow`}
            >
              <span className="text-2xl">{item.icon}</span>
              <span className="text-xs font-medium text-gray-700">{item.label}</span>
            </button>
          ))}
        </div>

        {/* App Info */}
        <div className="mt-6 bg-gray-100 rounded-xl p-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-green-600 rounded-xl flex items-center justify-center">
              <span className="text-2xl">🏥</span>
            </div>
            <div>
              <h4 className="font-bold text-gray-800">صيدلية مصر</h4>
              <p className="text-gray-500 text-sm">نسخة 1.0.0</p>
            </div>
          </div>
          <div className="flex gap-2 text-sm">
            <button className="flex-1 bg-white text-gray-700 py-2 rounded-lg font-medium">
              سياسة الخصوصية
            </button>
            <button className="flex-1 bg-white text-gray-700 py-2 rounded-lg font-medium">
              الشروط والأحكام
            </button>
          </div>
        </div>

        {/* Logout */}
        {isLoggedIn && (
          <button className="w-full mt-4 bg-red-50 text-red-600 py-3 rounded-xl font-semibold hover:bg-red-100 transition-colors">
            تسجيل خروج
          </button>
        )}
      </div>
    </div>
  );
};

export default ProfilePage;