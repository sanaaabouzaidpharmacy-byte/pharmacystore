import React, { useState } from 'react';
import { Product, categories } from '../data/products';
import ProductCard from '../components/ProductCard';

interface CategoriesPageProps {
  onNavigate: (page: string, product?: Product) => void;
  onAddToCart: (product: Product) => void;
  products: Product[];
}

const CategoriesPage: React.FC<CategoriesPageProps> = ({ onNavigate, onAddToCart, products }) => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedSubcategory, setSelectedSubcategory] = useState<string | null>(null);

  const currentCategories = selectedCategory
    ? categories.find(c => c.id === selectedCategory)?.subcategories || []
    : [];

  const filteredProducts = selectedSubcategory
    ? products.filter(p => p.subcategory === selectedSubcategory)
    : selectedCategory
      ? products.filter(p => p.category === selectedCategory)
      : [];

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="bg-gradient-to-l from-green-800 to-green-600 text-white px-4 py-5">
        <h1 className="text-xl font-bold">الأقسام</h1>
        <p className="text-green-200 text-sm mt-1">اختر القسم المناسب</p>
      </div>

      {/* Breadcrumb */}
      {(selectedCategory || selectedSubcategory) && (
        <div className="px-4 py-3 flex items-center gap-2 bg-gray-100">
          <button
            onClick={() => {
              if (selectedSubcategory) {
                setSelectedSubcategory(null);
              } else {
                setSelectedCategory(null);
              }
            }}
            className="text-green-600 flex items-center gap-1 text-sm"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            رجوع
          </button>
          <span className="text-gray-400">|</span>
          <span className="text-gray-600 text-sm">
            {selectedSubcategory || selectedCategory}
          </span>
        </div>
      )}

      {/* Categories Grid */}
      {!selectedCategory ? (
        <div className="px-4 py-5">
          <div className="grid grid-cols-2 gap-4">
            {categories.map(category => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className="bg-white rounded-2xl p-5 shadow-sm hover:shadow-lg transition-all text-center"
              >
                <div className={`w-20 h-20 mx-auto rounded-2xl flex items-center justify-center mb-3 ${
                  category.id === 'medicine' ? 'bg-red-50' : 'bg-pink-50'
                }`}>
                  <span className="text-5xl">{category.icon}</span>
                </div>
                <h3 className="font-bold text-lg text-gray-800">{category.name}</h3>
                <p className="text-gray-500 text-sm mt-1">
                  {products.filter(p => p.category === category.id).length} منتج
                </p>
              </button>
            ))}
          </div>
        </div>
      ) : !selectedSubcategory ? (
        /* Subcategories */
        <div className="px-4 py-5">
          <h2 className="text-lg font-bold text-gray-800 mb-4">الأقسام الفرعية</h2>
          <div className="grid grid-cols-2 gap-3">
            {currentCategories.map((subcategory, index) => {
              const productCount = products.filter(p => p.subcategory === subcategory).length;
              return (
                <button
                  key={subcategory}
                  onClick={() => setSelectedSubcategory(subcategory)}
                  className="bg-white rounded-xl p-4 shadow-sm hover:shadow-md transition-all flex items-center gap-3"
                >
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                    selectedCategory === 'medicine' ? 'bg-red-50' : 'bg-pink-50'
                  }`}>
                    <span className="text-2xl">
                      {['💊', '🤧', '🫃', '💊', '🤧', '🦠', '🩺', '❤️', '🧠', '🦴'][index] || '📦'}
                    </span>
                  </div>
                  <div className="text-right flex-1">
                    <h4 className="font-semibold text-gray-800">{subcategory}</h4>
                    <p className="text-gray-500 text-xs">{productCount} منتج</p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      ) : (
        /* Products Grid */
        <div className="px-4 py-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-gray-800">{selectedSubcategory}</h2>
            <span className="text-gray-500 text-sm">{filteredProducts.length} منتج</span>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {filteredProducts.map(product => (
              <ProductCard
                key={product.id}
                product={product}
                onClick={() => onNavigate('product-details', product)}
                onAddToCart={() => onAddToCart(product)}
              />
            ))}
          </div>
          {filteredProducts.length === 0 && (
            <div className="text-center py-10">
              <span className="text-5xl mb-3 block">📦</span>
              <p className="text-gray-500">لا توجد منتجات في هذا القسم</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default CategoriesPage;