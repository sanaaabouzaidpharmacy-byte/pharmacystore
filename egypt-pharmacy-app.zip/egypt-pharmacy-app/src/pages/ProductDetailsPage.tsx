import React, { useState } from 'react';
import { Product } from '../data/products';

interface ProductDetailsPageProps {
  product: Product;
  onNavigate: (page: string, product?: Product) => void;
  onAddToCart: (product: Product) => void;
}

const ProductDetailsPage: React.FC<ProductDetailsPageProps> = ({ product, onNavigate, onAddToCart }) => {
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      onAddToCart(product);
    }
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="bg-gradient-to-l from-green-800 to-green-600 text-white px-4 py-4 flex items-center gap-4">
        <button
          onClick={() => onNavigate('home')}
          className="p-2 hover:bg-white/10 rounded-full transition-colors"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <h1 className="text-lg font-bold flex-1">تفاصيل المنتج</h1>
      </div>

      {/* Product Image */}
      <div className="bg-gradient-to-br from-gray-100 to-gray-50 p-8 flex items-center justify-center">
        <div className="w-48 h-48 bg-white rounded-3xl shadow-lg flex items-center justify-center">
          <span className="text-8xl">{product.category === 'medicine' ? '💊' : '💄'}</span>
        </div>
      </div>

      {/* Product Info */}
      <div className="px-4 py-5">
        {/* Badge */}
        <div className="flex items-center gap-2 mb-3">
          {product.requiresPrescription && (
            <span className="bg-red-100 text-red-600 px-3 py-1 rounded-full text-xs font-medium">
              يحتاج وصفة
            </span>
          )}
          {product.originalPrice && (
            <span className="bg-green-100 text-green-600 px-3 py-1 rounded-full text-xs font-medium">
              عرض
            </span>
          )}
          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
            product.inStock ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-500'
          }`}>
            {product.inStock ? 'متوفر' : 'غير متوفر'}
          </span>
        </div>

        {/* Title & Price */}
        <h1 className="text-2xl font-bold text-gray-800 mb-2">{product.nameAr}</h1>
        <p className="text-gray-500 mb-4">{product.name}</p>

        <div className="flex items-center gap-3 mb-6">
          <span className="text-3xl font-bold text-green-600">{product.price.toFixed(2)} ج.م</span>
          {product.originalPrice && (
            <span className="text-xl text-gray-400 line-through">{product.originalPrice.toFixed(2)} ج.م</span>
          )}
          {product.originalPrice && (
            <span className="bg-red-100 text-red-600 px-2 py-1 rounded-lg text-sm font-bold">
              {Math.round((1 - product.price / product.originalPrice) * 100)}% خصم
            </span>
          )}
        </div>

        {/* Manufacturer */}
        <div className="bg-gray-50 rounded-xl p-4 mb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
              <span className="text-xl">🏭</span>
            </div>
            <div>
              <p className="text-gray-500 text-sm">الشركة المصنعة</p>
              <p className="font-semibold text-gray-800">{product.manufacturer}</p>
            </div>
          </div>
        </div>

        {/* Description */}
        <div className="mb-5">
          <h3 className="font-bold text-gray-800 mb-2">الوصف</h3>
          <p className="text-gray-600 leading-relaxed">{product.description}</p>
        </div>

        {/* Active Ingredient */}
        {product.activeIngredient && (
          <div className="mb-5">
            <h3 className="font-bold text-gray-800 mb-2">المادة الفعالة</h3>
            <p className="text-gray-600">{product.activeIngredient}</p>
          </div>
        )}

        {/* Dosage */}
        {product.dosage && (
          <div className="mb-5">
            <h3 className="font-bold text-gray-800 mb-2">الجرعة</h3>
            <p className="text-gray-600">{product.dosage}</p>
          </div>
        )}

        {/* Category */}
        <div className="mb-5">
          <h3 className="font-bold text-gray-800 mb-2">القسم</h3>
          <div className="flex items-center gap-2">
            <span className="text-xl">{product.category === 'medicine' ? '💊' : '💄'}</span>
            <span className="text-gray-600">{product.subcategory}</span>
          </div>
        </div>
      </div>

      {/* Bottom Actions */}
      <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-gray-200 px-4 py-4 flex items-center gap-4 z-50">
        {/* Quantity Selector */}
        <div className="flex items-center gap-3 bg-gray-100 rounded-xl p-2">
          <button
            onClick={() => setQuantity(Math.max(1, quantity - 1))}
            className="w-10 h-10 bg-white rounded-lg flex items-center justify-center text-gray-600 hover:bg-gray-200 transition-colors font-bold text-xl"
          >
            -
          </button>
          <span className="w-8 text-center font-bold text-lg">{quantity}</span>
          <button
            onClick={() => setQuantity(quantity + 1)}
            className="w-10 h-10 bg-white rounded-lg flex items-center justify-center text-green-600 hover:bg-green-50 transition-colors font-bold text-xl"
          >
            +
          </button>
        </div>

        {/* Add to Cart Button */}
        <button
          onClick={handleAddToCart}
          disabled={!product.inStock}
          className={`flex-1 py-4 rounded-xl font-bold text-lg transition-all ${
            added
              ? 'bg-green-500 text-white'
              : product.inStock
                ? 'bg-gradient-to-l from-green-700 to-green-500 text-white hover:from-green-800 hover:to-green-600'
                : 'bg-gray-200 text-gray-400 cursor-not-allowed'
          }`}
        >
          {added ? '✓ تمت الإضافة' : product.inStock ? 'إضافة للسلة' : 'غير متوفر'}
        </button>
      </div>
    </div>
  );
};

export default ProductDetailsPage;