import React from 'react';
import { Product } from '../data/products';
import ProductCard from '../components/ProductCard';

interface HomePageProps {
  onNavigate: (page: string, product?: Product) => void;
  onSearch: (query: string) => void;
  onAddToCart: (product: Product) => void;
  products: Product[];
}

const HomePage: React.FC<HomePageProps> = ({ onNavigate, onSearch, onAddToCart, products }) => {
  const [searchInput, setSearchInput] = React.useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      onSearch(searchInput);
    }
  };

  const medicineProducts = products.filter(p => p.category === 'medicine').slice(0, 6);
  const cosmeticsProducts = products.filter(p => p.category === 'cosmetics').slice(0, 6);
  const offers = products.filter(p => p.originalPrice).slice(0, 4);

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="bg-gradient-to-l from-green-800 to-green-600 text-white px-4 py-6 rounded-b-3xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-green-200 text-sm">مرحباً بك</p>
            <h1 className="text-xl font-bold">صيدلية مصر</h1>
          </div>
          <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
            <span className="text-2xl">🏥</span>
          </div>
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="relative">
          <input
            type="text"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="ابحث عن دواء أو منتج..."
            className="w-full bg-white text-gray-800 rounded-full py-3 px-5 pr-12 text-right placeholder-gray-400 shadow-lg"
          />
          <button type="submit" className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </button>
        </form>
      </div>

      {/* Quick Categories */}
      <div className="px-4 py-5">
        <div className="grid grid-cols-4 gap-3">
          <button
            onClick={() => onNavigate('categories')}
            className="flex flex-col items-center gap-2 p-3 bg-white rounded-2xl shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="w-12 h-12 bg-red-50 rounded-xl flex items-center justify-center">
              <span className="text-2xl">💊</span>
            </div>
            <span className="text-xs font-medium text-gray-700">أدوية</span>
          </button>
          <button
            onClick={() => onNavigate('categories')}
            className="flex flex-col items-center gap-2 p-3 bg-white rounded-2xl shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="w-12 h-12 bg-pink-50 rounded-xl flex items-center justify-center">
              <span className="text-2xl">💄</span>
            </div>
            <span className="text-xs font-medium text-gray-700">تجميل</span>
          </button>
          <button
            onClick={() => onNavigate('categories')}
            className="flex flex-col items-center gap-2 p-3 bg-white rounded-2xl shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center">
              <span className="text-2xl">🧴</span>
            </div>
            <span className="text-xs font-medium text-gray-700">عناية</span>
          </button>
          <button
            onClick={() => onNavigate('categories')}
            className="flex flex-col items-center gap-2 p-3 bg-white rounded-2xl shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center">
              <span className="text-2xl">🌿</span>
            </div>
            <span className="text-xs font-medium text-gray-700">فيتامينات</span>
          </button>
        </div>
      </div>

      {/* Offers Section */}
      {offers.length > 0 && (
        <div className="px-4 mb-5">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-bold text-gray-800">🔥 عروض اليوم</h2>
            <button className="text-green-600 text-sm font-medium">عرض الكل</button>
          </div>
          <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2 -mx-4 px-4">
            {offers.map(product => (
              <div
                key={product.id}
                className="min-w-[160px] bg-gradient-to-br from-red-500 to-orange-500 rounded-2xl p-3 text-white cursor-pointer"
                onClick={() => onNavigate('product-details', product)}
              >
                <div className="w-full h-24 bg-white/20 rounded-xl mb-2 flex items-center justify-center">
                  <span className="text-4xl opacity-50">💊</span>
                </div>
                <p className="font-semibold text-sm mb-1">{product.nameAr}</p>
                <div className="flex items-center gap-2">
                  <span className="font-bold">{product.price.toFixed(2)} ج.م</span>
                  {product.originalPrice && (
                    <span className="text-xs line-through opacity-75">{product.originalPrice.toFixed(2)}</span>
                  )}
                </div>
                <div className="mt-1 bg-white/20 rounded-full text-xs text-center py-1">
                  خصم {Math.round((1 - product.price / (product.originalPrice || product.price)) * 100)}%
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Popular Medicines */}
      <div className="px-4 mb-5">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-bold text-gray-800">💊 الأدوية الشائعة</h2>
          <button onClick={() => onNavigate('categories')} className="text-green-600 text-sm font-medium">عرض الكل</button>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {medicineProducts.map(product => (
            <ProductCard
              key={product.id}
              product={product}
              onClick={() => onNavigate('product-details', product)}
              onAddToCart={() => onAddToCart(product)}
            />
          ))}
        </div>
      </div>

      {/* Cosmetics Section */}
      <div className="px-4 mb-5">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-bold text-gray-800">💄 مستحضرات التجميل</h2>
          <button onClick={() => onNavigate('categories')} className="text-green-600 text-sm font-medium">عرض الكل</button>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {cosmeticsProducts.map(product => (
            <ProductCard
              key={product.id}
              product={product}
              onClick={() => onNavigate('product-details', product)}
              onAddToCart={() => onAddToCart(product)}
            />
          ))}
        </div>
      </div>

      {/* App Features Banner */}
      <div className="px-4 mb-5">
        <div className="bg-gradient-to-l from-green-700 to-green-500 rounded-2xl p-5 text-white">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center">
              <span className="text-4xl">🚚</span>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-1">توصيل سريع</h3>
              <p className="text-green-100 text-sm">احصل على أدويتك ومستحضراتك في وقت سريع</p>
            </div>
          </div>
        </div>
      </div>

      {/* Info Section */}
      <div className="px-4 pb-8">
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
            <span className="text-xl">ℹ️</span> معلومات مهمة
          </h3>
          <ul className="space-y-2 text-sm text-gray-600">
            <li className="flex items-start gap-2">
              <span className="text-green-500">•</span>
              بعض الأدوية تحتاج وصفة طبية
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-500">•</span>
              الأسعار قابلة للتغيير
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-500">•</span>
              استشر الصيدلي دائماً
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default HomePage;