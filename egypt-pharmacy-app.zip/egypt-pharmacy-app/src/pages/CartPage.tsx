import React from 'react';
import { CartItem } from '../App';

interface CartPageProps {
  cart: CartItem[];
  onNavigate: (page: string, product?: any) => void;
  onRemove: (productId: number) => void;
  onUpdateQuantity: (productId: number, quantity: number) => void;
  total: number;
}

const CartPage: React.FC<CartPageProps> = ({ cart, onNavigate, onRemove, onUpdateQuantity, total }) => {
  const deliveryFee = 25;
  const finalTotal = total + deliveryFee;

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="bg-gradient-to-l from-green-800 to-green-600 text-white px-4 py-5">
        <h1 className="text-xl font-bold">سلة التسوق</h1>
        <p className="text-green-200 text-sm mt-1">{cart.length} منتجات</p>
      </div>

      {cart.length === 0 ? (
        /* Empty Cart */
        <div className="flex flex-col items-center justify-center py-20 px-4">
          <div className="w-32 h-32 bg-gray-100 rounded-full flex items-center justify-center mb-4">
            <span className="text-6xl">🛒</span>
          </div>
          <h2 className="text-xl font-bold text-gray-800 mb-2">السلة فارغة</h2>
          <p className="text-gray-500 text-center mb-6">لم تضف أي منتجات بعد</p>
          <button
            onClick={() => onNavigate('home')}
            className="bg-green-600 text-white px-8 py-3 rounded-full font-semibold hover:bg-green-700 transition-colors"
          >
            تصفح المنتجات
          </button>
        </div>
      ) : (
        <>
          {/* Cart Items */}
          <div className="px-4 py-4 space-y-3">
            {cart.map(item => (
              <div
                key={item.id}
                className="bg-white rounded-xl p-4 shadow-sm flex gap-4"
              >
                {/* Product Image */}
                <div className="w-20 h-20 bg-gray-100 rounded-xl flex items-center justify-center flex-shrink-0">
                  <span className="text-3xl">{item.category === 'medicine' ? '💊' : '💄'}</span>
                </div>

                {/* Product Info */}
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold text-gray-800 text-sm">{item.nameAr}</h3>
                      <p className="text-gray-500 text-xs mt-1">{item.manufacturer}</p>
                    </div>
                    <button
                      onClick={() => onRemove(item.id)}
                      className="text-red-400 hover:text-red-600 p-1"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </div>

                  <div className="flex justify-between items-center mt-3">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                        className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center text-gray-600 hover:bg-gray-200 transition-colors"
                      >
                        -
                      </button>
                      <span className="w-8 text-center font-semibold">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                        className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center text-green-600 hover:bg-green-200 transition-colors"
                      >
                        +
                      </button>
                    </div>
                    <div className="text-left">
                      <p className="font-bold text-green-600">{(item.price * item.quantity).toFixed(2)} ج.م</p>
                      {item.quantity > 1 && (
                        <p className="text-gray-400 text-xs">{item.price.toFixed(2)} ج.م / للوحدة</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Order Summary */}
          <div className="px-4 py-4">
            <div className="bg-white rounded-xl p-4 shadow-sm">
              <h3 className="font-bold text-gray-800 mb-4">ملخص الطلب</h3>

              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">المجموع الفرعي</span>
                  <span className="font-semibold">{total.toFixed(2)} ج.م</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">رسوم التوصيل</span>
                  <span className="font-semibold">{deliveryFee} ج.م</span>
                </div>
                <div className="border-t pt-3 flex justify-between">
                  <span className="font-bold text-gray-800">الإجمالي</span>
                  <span className="font-bold text-green-600 text-lg">{finalTotal.toFixed(2)} ج.م</span>
                </div>
              </div>
            </div>

            {/* Prescription Notice */}
            {cart.some(item => item.requiresPrescription) && (
              <div className="mt-3 bg-yellow-50 border border-yellow-200 rounded-xl p-4">
                <div className="flex items-start gap-3">
                  <span className="text-2xl">⚠️</span>
                  <div>
                    <h4 className="font-semibold text-yellow-800">تنبيه</h4>
                    <p className="text-yellow-700 text-sm mt-1">
                      بعض المنتجات تحتاج وصفة طبية. سيتم التواصل معك لتأكيد الطلب.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Checkout Button */}
            <button className="w-full mt-4 bg-gradient-to-l from-green-700 to-green-500 text-white py-4 rounded-xl font-bold text-lg hover:from-green-800 hover:to-green-600 transition-all shadow-lg">
              إتمام الطلب - {finalTotal.toFixed(2)} ج.م
            </button>

            {/* Continue Shopping */}
            <button
              onClick={() => onNavigate('home')}
              className="w-full mt-3 text-green-600 py-3 font-medium text-center"
            >
              استمرار التسوق
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default CartPage;