import React from 'react';
import { Product } from '../data/products';

interface ProductCardProps {
  product: Product;
  onClick: () => void;
  onAddToCart: () => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onClick, onAddToCart }) => {
  const hasDiscount = product.originalPrice && product.originalPrice > product.price;
  const discountPercent = hasDiscount
    ? Math.round((1 - product.price / product.originalPrice!) * 100)
    : 0;

  return (
    <div
      className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-lg transition-all cursor-pointer"
      onClick={onClick}
    >
      {/* Image */}
      <div className={`relative p-4 ${
        product.category === 'medicine' ? 'bg-red-50' : 'bg-pink-50'
      }`}>
        {hasDiscount && (
          <div className="absolute top-2 right-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
            -{discountPercent}%
          </div>
        )}
        <div className="w-full h-28 flex items-center justify-center">
          <span className="text-5xl opacity-50">{product.category === 'medicine' ? '💊' : '💄'}</span>
        </div>
      </div>

      {/* Info */}
      <div className="p-3">
        <h3 className="font-semibold text-gray-800 text-sm mb-1 line-clamp-2 leading-tight">
          {product.nameAr}
        </h3>
        <p className="text-gray-400 text-xs mb-2 truncate">{product.manufacturer}</p>

        <div className="flex items-center justify-between">
          <div>
            <p className="font-bold text-green-600">{product.price.toFixed(2)}</p>
            {hasDiscount && (
              <p className="text-gray-400 text-xs line-through">{product.originalPrice?.toFixed(2)}</p>
            )}
          </div>

          <button
            onClick={(e) => {
              e.stopPropagation();
              onAddToCart();
            }}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
              product.category === 'medicine'
                ? 'bg-red-100 text-red-600 hover:bg-red-200'
                : 'bg-pink-100 text-pink-600 hover:bg-pink-200'
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;